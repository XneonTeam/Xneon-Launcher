import type { AuthSession, LoaderType, OfflineAuth } from "./types/index.js";
export type LaunchRequestOptions = {
    mcVersion?: string;
    version?: string;
    modLoader?: string;
    loaderType?: LoaderType;
    loaderVersion?: string;
    memoryMin?: string;
    memoryMax?: string;
    javaPath?: string;
    width?: number;
    height?: number;
};
export type ResolvedLaunchRequest = {
    mcVersion: string;
    loaderType: LoaderType;
    loaderVersion?: string;
    memoryMin: string;
    memoryMax: string;
    javaPath?: string;
    width: number;
    height: number;
};
export type MinecraftRootOptions = {
    platform?: NodeJS.Platform;
    homeDir: string;
    appDataDir?: string;
    launcherDirName?: string;
};
export type MinecraftRootEnvOptions = {
    platform?: NodeJS.Platform;
    env?: NodeJS.ProcessEnv;
    launcherDirName?: string;
};
export type AuthorizationAccount = {
    type: string;
    accessToken?: string;
    uuid?: string;
    username: string;
};
export type XnlcHandlerLike = {
    getVersions(): Promise<Array<{
        id: string;
        type: string;
    }>>;
};
export declare function getDefaultMinecraftRoot(options: MinecraftRootOptions): string;
export declare function getDefaultMinecraftRootFromEnv(options?: MinecraftRootEnvOptions): string;
export declare function ensureAuthlibInjector(rootPath: string): Promise<string>;
export declare function ensureRetroAuthInjector(rootPath: string): Promise<string>;
export declare function createLaunchAuth(account: AuthorizationAccount): AuthSession | OfflineAuth;
export declare function resolveLaunchRequest(options: LaunchRequestOptions): ResolvedLaunchRequest | {
    error: string;
};
export declare function collectSupportedVersions(handler: XnlcHandlerLike, resolver: (handler: XnlcHandlerLike, versionId: string) => Promise<unknown[]>, limit?: number): Promise<string[]>;
//# sourceMappingURL=launch-utils.d.ts.map