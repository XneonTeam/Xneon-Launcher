import { Downloader } from "./downloader.js";
export interface JavaRuntime {
    path: string;
    version: number;
    vendor: string;
}
export declare class JavaManager {
    private downloader;
    private gameDir;
    constructor(downloader: Downloader, gameDir: string);
    /**
     * Detect the Java version of a given java binary.
     * Returns the major version number (e.g. 21, 25).
     */
    detectJavaVersion(javaPath?: string): number;
    /**
     * Find a suitable Java runtime for the required version.
     * Checks:
     * 1. User-provided javaPath
     * 2. System PATH java
     * 3. Previously downloaded runtime in gameDir
     * 4. Downloads from Azul Zulu if needed
     */
    findOrDownloadJava(requiredVersion: number, userJavaPath?: string, onProgress?: (pct: number) => void): Promise<JavaRuntime>;
    /**
     * Check if a Java version is compatible with the required version.
     * For Java 8 requirement, only Java 8 is compatible (launchwrapper breaks on 9+).
     * For Java 17+ requirement, any version >= required is fine.
     */
    private isJavaCompatible;
    /**
     * Check if a previously downloaded runtime exists in the game directory.
     */
    private getDownloadedRuntime;
    /**
     * Download Java from Azul Zulu.
     */
    private downloadJava;
    /**
     * Get the Azul Zulu download URL for a specific Java version and platform.
     */
    private getAzulDownloadUrl;
    /**
     * Extract a tar.gz or zip archive.
     */
    private extractArchive;
    /**
     * Find the java binary in an extracted JDK directory.
     */
    private findJavaBinary;
    /**
     * Get platform info for Azul Zulu API.
     */
    private getPlatformInfo;
}
//# sourceMappingURL=java-manager.d.ts.map