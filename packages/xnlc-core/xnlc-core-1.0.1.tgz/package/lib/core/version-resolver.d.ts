import { VersionJson, VersionJsonLibrary } from "../types/index.js";
import { MetaClient } from "./meta-client.js";
import { OSInfo } from "../types/index.js";
export declare class VersionResolver {
    private metaClient;
    constructor(metaClient: MetaClient);
    resolveVersion(versionId: string, osInfo: OSInfo): Promise<VersionJson>;
    resolveVersionFromJson(versionJson: VersionJson, osInfo: OSInfo): Promise<VersionJson>;
    private resolveInheritance;
    private mergeLibraries;
    private mergeArguments;
    filterLibrariesForOS(libraries: VersionJsonLibrary[], osInfo: OSInfo): VersionJsonLibrary[];
}
//# sourceMappingURL=version-resolver.d.ts.map