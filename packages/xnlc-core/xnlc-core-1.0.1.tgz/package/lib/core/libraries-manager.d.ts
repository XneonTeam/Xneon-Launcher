import { VersionJson, VersionJsonLibrary, ResolvedLibrary, OSInfo, DownloadProgressCallback } from "../types/index.js";
import { Downloader } from "./downloader.js";
export declare class LibrariesManager {
    private downloader;
    private gameDir;
    private osInfo;
    constructor(downloader: Downloader, gameDir: string, osInfo: OSInfo);
    getOsInfo(): OSInfo;
    countTotalFiles(versionJson: VersionJson): number;
    countTotalSize(versionJson: VersionJson): number;
    resolveAndDownload(versionJson: VersionJson, onProgress?: DownloadProgressCallback): Promise<ResolvedLibrary[]>;
    resolveLibraries(versionJson: VersionJson): VersionJsonLibrary[];
    getLibraryPath(lib: VersionJsonLibrary): string;
    isNativeLibrary(lib: VersionJsonLibrary): boolean;
    getClassifier(lib: VersionJsonLibrary): string | undefined;
    getNativesLibraries(versionJson: VersionJson): VersionJsonLibrary[];
    getNonNativeLibraries(versionJson: VersionJson): VersionJsonLibrary[];
    buildClasspath(libraries: ResolvedLibrary[]): string;
}
//# sourceMappingURL=libraries-manager.d.ts.map