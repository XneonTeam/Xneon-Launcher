import { DownloadProgressCallback } from "../types/index.js";
export interface DownloadOptions {
    url: string;
    dest: string;
    sha1?: string;
    size?: number;
    onProgress?: DownloadProgressCallback;
    retries?: number;
}
export declare class Downloader {
    constructor();
    download(options: DownloadOptions): Promise<void>;
    private downloadOnce;
    downloadMultiple(items: DownloadOptions[], concurrency?: number): Promise<void>;
}
//# sourceMappingURL=downloader.d.ts.map