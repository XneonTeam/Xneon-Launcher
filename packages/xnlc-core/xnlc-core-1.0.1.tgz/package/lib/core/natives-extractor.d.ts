import { VersionJson } from "../types/index.js";
import { LibrariesManager } from "./libraries-manager.js";
export declare class NativesExtractor {
    private librariesManager;
    constructor(librariesManager: LibrariesManager);
    extractNatives(versionJson: VersionJson, gameDir: string): Promise<string>;
    /**
     * Find the path to the native jar for the current OS.
     * Handles both artifact-based and classifier-based libraries.
     * Prefers classifiers natives jar over artifact when available.
     */
    private findNativeJarPath;
    getNativesDir(gameDir: string): string;
}
//# sourceMappingURL=natives-extractor.d.ts.map