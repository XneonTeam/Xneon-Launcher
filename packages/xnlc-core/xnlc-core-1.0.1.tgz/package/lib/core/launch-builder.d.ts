import { VersionJson, OSInfo, AuthSession, ResolvedLibrary } from "../types/index.js";
export interface LaunchCommand {
    javaPath: string;
    jvmArgs: string[];
    mainClass: string;
    gameArgs: string[];
    classpath: string;
}
export declare class LaunchBuilder {
    private osInfo;
    private gameDir;
    private launcherName;
    private launcherVersion;
    private javaVersionCache;
    constructor(osInfo: OSInfo, gameDir: string, launcherName?: string, launcherVersion?: string);
    build(versionJson: VersionJson, auth: AuthSession, libraries: ResolvedLibrary[], javaPath: string, customJvmArgs?: string[], customGameArgs?: string[], memoryMin?: string, memoryMax?: string, width?: number, height?: number): LaunchCommand;
    private buildClasspath;
    private buildJvmArgs;
    private readonly JVM_ARGS_MIN_JAVA;
    private filterJvmArgs;
    private detectJavaVersion;
    private buildGameArgs;
    private shouldIncludeArg;
    private getMemoryArgs;
    private getPlatformJvmArgs;
    private resolveArgumentValues;
    private replaceJvmPlaceholders;
    private replaceGamePlaceholders;
    private replacePlaceholders;
}
//# sourceMappingURL=launch-builder.d.ts.map