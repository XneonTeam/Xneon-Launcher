import { VersionJson, AssetIndex, DownloadProgressCallback } from "../types/index.js";
import { Downloader } from "./downloader.js";
export declare class AssetsManager {
    private downloader;
    constructor(downloader: Downloader);
    private ensureAssetIndex;
    countAssets(versionJson: VersionJson, gameDir: string): Promise<number>;
    countTotalSize(versionJson: VersionJson, gameDir: string): Promise<number>;
    downloadAssets(versionJson: VersionJson, gameDir: string, onProgress?: DownloadProgressCallback): Promise<void>;
    getAssetIndex(versionJson: VersionJson, gameDir: string): Promise<AssetIndex>;
    getAssetId(versionJson: VersionJson): string;
}
//# sourceMappingURL=assets-manager.d.ts.map