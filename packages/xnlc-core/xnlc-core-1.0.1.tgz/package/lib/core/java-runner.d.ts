import { LaunchCommand } from "./launch-builder.js";
import { LaunchResult } from "../types/index.js";
export declare class JavaRunner {
    private currentProcess;
    private pipeOutputToConsole;
    setPipeOutputToConsole(enabled: boolean): void;
    launch(command: LaunchCommand, gameDir: string): LaunchResult;
    getCurrentProcess(): import("child_process").ChildProcess | null;
}
//# sourceMappingURL=java-runner.d.ts.map