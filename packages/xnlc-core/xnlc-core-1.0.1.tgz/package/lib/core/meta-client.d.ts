import { MojangVersionManifest, MojangVersionEntry, VersionJson } from "../types/index.js";
export declare class MetaClient {
    private cache;
    private manifestCache;
    constructor();
    fetchManifest(): Promise<MojangVersionManifest>;
    getVersionEntry(versionId: string): Promise<MojangVersionEntry | undefined>;
    fetchVersionJson(versionId: string): Promise<VersionJson>;
    getLatestRelease(): Promise<string>;
    getLatestSnapshot(): Promise<string>;
    getVersionsByType(type: string): Promise<MojangVersionEntry[]>;
    getAllVersions(): Promise<MojangVersionEntry[]>;
    clearCache(): void;
}
//# sourceMappingURL=meta-client.d.ts.map