export declare function ensureDirSync(dir: string): void;
//# sourceMappingURL=sync.d.ts.map