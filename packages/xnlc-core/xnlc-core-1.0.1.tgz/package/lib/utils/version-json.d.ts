import type { OSInfo, VersionJson } from "../types/index.js";
export declare function getRequiredJavaVersion(versionJson: VersionJson): number;
export declare function shouldRepairOptifineProfile(versionJson: VersionJson, osInfo: OSInfo): boolean;
//# sourceMappingURL=version-json.d.ts.map