import type { OSType, OSInfo, VersionJsonArgumentValue } from "../types/index.js";
export * from "./sync.js";
export * from "./paths.js";
export * from "./urls.js";
export * from "./version-json.js";
export declare function getOSInfo(): OSInfo;
export declare function getNativesClassifier(osInfo: OSInfo): string;
export declare function getNativesClassifierOld(osInfo: OSInfo): string;
export declare function getOSRuleName(osInfo: OSInfo): OSType;
export declare function getArchRule(osInfo: OSInfo): string;
export declare function libraryNameToPath(name: string): string;
export declare function libraryNameToParts(name: string): {
    groupId: string;
    artifactId: string;
    version: string;
    classifier?: string;
    ext: string;
};
export declare function sha1Hash(data: Buffer): string;
export declare function sha1HashSync(filePath: string): string;
export declare function generateOfflineUUID(username: string): string;
export interface RuleCheck {
    action: "allow" | "disallow";
    os?: {
        name?: string;
        arch?: string;
    };
    features?: Record<string, boolean>;
}
export declare function checkRules(rules: RuleCheck[], osInfo: OSInfo, features?: Record<string, boolean>): boolean;
export declare function tokenizeCommandLine(input: string): string[];
export interface ParsedLaunchArgument {
    name: string;
    value?: string;
    index: number;
    raw: string;
}
export declare function flattenVersionJsonArguments(argDefs: (string | VersionJsonArgumentValue)[], features?: Record<string, boolean>, osInfo?: OSInfo): string[];
export declare function parseLaunchArguments(args: string[]): ParsedLaunchArgument[];
export declare function hasLaunchArgument(args: string[], name: string): boolean;
export declare function getLaunchArgumentValues(args: string[], name: string): string[];
export declare function countLaunchArgument(args: string[], name: string): number;
export declare function formatBytes(bytes: number): string;
export declare function isLegacyVersion(mcVersion: string): boolean;
export declare function isLegacyForge(mcVersion: string, _forgeVersion: string): boolean;
export declare function isLegacyFabric(fabricLoaderVersion: string): boolean;
export declare function parseMavenCoordinate(coord: string): {
    groupId: string;
    artifactId: string;
    version: string;
    classifier?: string;
    extension: string;
};
export declare function mavenCoordinateToPath(groupId: string, artifactId: string, version: string, classifier?: string, extension?: string): string;
//# sourceMappingURL=index.d.ts.map