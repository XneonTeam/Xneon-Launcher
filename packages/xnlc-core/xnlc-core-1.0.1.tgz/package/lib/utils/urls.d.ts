export declare function rewriteUrl(url: string): string;
//# sourceMappingURL=urls.d.ts.map