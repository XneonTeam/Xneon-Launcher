export declare function getGameDirStructure(gameDir: string): Record<string, string>;
export declare const getVersionDir: (gameDir: string, version: string) => string;
export declare const getLibraryDir: (gameDir: string) => string;
export declare const getNativesDir: (gameDir: string) => string;
export declare const getAssetsDir: (gameDir: string) => string;
export declare const getAssetIndexDir: (gameDir: string) => string;
export declare const getAssetObjectsDir: (gameDir: string) => string;
export declare const getLogsDir: (gameDir: string) => string;
export declare const getRuntimeDir: (gameDir: string) => string;
export declare const getModsDir: (gameDir: string) => string;
export declare const getConfigDir: (gameDir: string) => string;
export declare const getResourcepacksDir: (gameDir: string) => string;
export declare const getSavesDir: (gameDir: string) => string;
export declare const getScreenshotsDir: (gameDir: string) => string;
export declare const getShaderpacksDir: (gameDir: string) => string;
export declare const getCrashReportsDir: (gameDir: string) => string;
//# sourceMappingURL=paths.d.ts.map