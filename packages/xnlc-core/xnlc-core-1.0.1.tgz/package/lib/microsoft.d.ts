export type MicrosoftAccountPayload = {
    id: string;
    username: string;
    uuid: string;
    accessToken: string;
    refreshToken: string;
};
export type MicrosoftAuthOptions = {
    clientId?: string;
    redirectUri?: string;
    scope?: string;
    authorizeUrl?: string;
    tokenUrl?: string;
    timeoutMs?: number;
};
export declare function getMicrosoftRedirectUri(options?: MicrosoftAuthOptions): string;
export declare function createMicrosoftAuthUrl(options?: MicrosoftAuthOptions): string;
export declare function exchangeMicrosoftCode(code: string, options?: MicrosoftAuthOptions): Promise<MicrosoftAccountPayload>;
//# sourceMappingURL=microsoft.d.ts.map