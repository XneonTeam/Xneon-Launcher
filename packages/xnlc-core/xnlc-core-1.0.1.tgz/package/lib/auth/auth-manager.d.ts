import { AuthSession, OfflineAuth } from "../types/index.js";
export declare class AuthManager {
    static createOfflineAuth(username: string): OfflineAuth;
    static validateAuth(auth: AuthSession): boolean;
}
//# sourceMappingURL=auth-manager.d.ts.map