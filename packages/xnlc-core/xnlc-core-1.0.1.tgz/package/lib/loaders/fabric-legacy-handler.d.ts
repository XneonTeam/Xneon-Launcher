import { FabricLoaderVersion, LoaderInstallResult, DownloadProgressCallback } from "../types/index.js";
import { Downloader } from "../core/downloader.js";
export declare class FabricLegacyHandler {
    private downloader;
    private gameDir;
    constructor(downloader: Downloader, gameDir: string);
    getLoaderVersionsForGame(mcVersion: string): Promise<FabricLoaderVersion[]>;
    install(mcVersion: string, loaderVersion: string, onProgress?: DownloadProgressCallback): Promise<LoaderInstallResult>;
    private normalizeLegacyProfile;
    private libraryNameToPath;
}
//# sourceMappingURL=fabric-legacy-handler.d.ts.map