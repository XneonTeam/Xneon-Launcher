import { QuiltGameVersion, QuiltLoaderVersion, LoaderInstallResult, DownloadProgressCallback } from "../types/index.js";
import { Downloader } from "../core/downloader.js";
export declare class QuiltHandler {
    private downloader;
    private gameDir;
    constructor(downloader: Downloader, gameDir: string);
    getGameVersions(): Promise<QuiltGameVersion[]>;
    getLoaderVersions(): Promise<QuiltLoaderVersion[]>;
    getLoaderVersionsForGame(mcVersion: string): Promise<QuiltLoaderVersion[]>;
    getLatestLoaderVersion(mcVersion: string): Promise<string | undefined>;
    install(mcVersion: string, loaderVersion: string, onProgress?: DownloadProgressCallback): Promise<LoaderInstallResult>;
    private normalizeProfile;
    private libraryNameToPath;
}
//# sourceMappingURL=quilt-handler.d.ts.map