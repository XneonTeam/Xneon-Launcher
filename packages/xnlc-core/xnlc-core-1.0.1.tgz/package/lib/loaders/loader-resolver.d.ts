import { LoaderType, DownloadProgressCallback, LoaderInstallResult } from "../types/index.js";
import { ForgeHandler } from "./forge-handler.js";
import { ForgeLegacyHandler } from "./forge-legacy-handler.js";
import { NeoForgeHandler } from "./neoforge-handler.js";
import { FabricHandler } from "./fabric-handler.js";
import { FabricLegacyHandler } from "./fabric-legacy-handler.js";
import { QuiltHandler } from "./quilt-handler.js";
import { OptifineHandler } from "./optifine-handler.js";
import { CustomVersionHandler } from "./custom-version-handler.js";
import { Downloader } from "../core/downloader.js";
import { MetaClient } from "../core/meta-client.js";
type ResolvedLoaderType = Exclude<LoaderType, "vanilla">;
export declare class LoaderResolver {
    private forgeHandler;
    private forgeLegacyHandler;
    private neoforgeHandler;
    private fabricHandler;
    private fabricLegacyHandler;
    private quiltHandler;
    private optifineHandler;
    private customVersionHandler;
    constructor(downloader: Downloader, metaClient: MetaClient, gameDir: string, customVersionsDir?: string);
    getForgeHandler(): ForgeHandler;
    getForgeLegacyHandler(): ForgeLegacyHandler;
    getNeoForgeHandler(): NeoForgeHandler;
    getFabricHandler(): FabricHandler;
    getFabricLegacyHandler(): FabricLegacyHandler;
    getQuiltHandler(): QuiltHandler;
    getOptifineHandler(): OptifineHandler;
    getCustomVersionHandler(): CustomVersionHandler;
    getHandler(loaderType: ResolvedLoaderType): ForgeHandler | ForgeLegacyHandler | NeoForgeHandler | FabricHandler | FabricLegacyHandler | QuiltHandler | OptifineHandler | CustomVersionHandler;
    installLoader(mcVersion: string, loaderType: LoaderType, loaderVersion: string, onProgress?: DownloadProgressCallback): Promise<LoaderInstallResult>;
    determineLoaderType(mcVersion: string, loaderType: LoaderType, loaderVersion: string): LoaderType;
    isLegacyForge(mcVersion: string): boolean;
    isLegacyFabric(loaderVersion: string): boolean;
}
export {};
//# sourceMappingURL=loader-resolver.d.ts.map