import type { LoaderInstallResult, DownloadProgressCallback } from "../types/index.js";
export declare class CustomVersionHandler {
    private customVersionsDir;
    constructor(customVersionsDir: string);
    getVersions(): Promise<string[]>;
    install(customVersionPath: string, _loaderVersion: string, _onProgress?: DownloadProgressCallback): Promise<LoaderInstallResult>;
}
//# sourceMappingURL=custom-version-handler.d.ts.map