import type { LoaderInstallResult, DownloadProgressCallback } from "../types/index.js";
import { Downloader } from "../core/downloader.js";
import { MetaClient } from "../core/meta-client.js";
export declare class NeoForgeHandler {
    private downloader;
    private metaClient;
    private gameDir;
    constructor(downloader: Downloader, metaClient: MetaClient, gameDir: string);
    private getProfileName;
    private getFamily;
    private getInstallerUrl;
    private normalizeLoaderVersion;
    private fetchMetadataXml;
    private parseVersionsFromMetadata;
    private mcPrefix;
    private matchesMinecraftVersion;
    private isStableVersion;
    /**
     * Fetch the NeoForge Maven metadata once and return all unique
     * Minecraft versions that have at least one NeoForge build available.
     *
     * Handles both old format (1.20.4 → NF prefix 20.4) and new format
     * (26.1.2 → NF prefix 26.1.2) by cross-referencing with the Mojang
     * version manifest.
     *
     * Single HTTP request for Maven + single request for Mojang manifest
     * instead of per-mc-version polling.
     */
    getSupportedMinecraftVersions(): Promise<string[]>;
    getVersions(mcVersion: string): Promise<string[]>;
    getRecommendedVersion(mcVersion: string): Promise<string | undefined>;
    getLatestVersion(mcVersion: string): Promise<string | undefined>;
    private withPhase;
    install(mcVersion: string, loaderVersion: string, onProgress?: DownloadProgressCallback): Promise<LoaderInstallResult>;
    private mergeBaseMetadata;
    private getFallbackArtifactUrl;
    private ensureArtifactAvailable;
    private downloadProfileLibraries;
    private ensureProfileArtifactAvailable;
    private downloadLibraries;
    private readInstallerJson;
    private ensureLauncherProfiles;
}
//# sourceMappingURL=neoforge-handler.d.ts.map