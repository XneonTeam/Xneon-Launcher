import type { LoaderInstallResult, DownloadProgressCallback } from "../types/index.js";
import { Downloader } from "../core/downloader.js";
import { MetaClient } from "../core/meta-client.js";
export interface OptifineVersion {
    mcVersion: string;
    edition: string;
    release: string;
    filename: string;
    downloadUrl: string;
    isPreview: boolean;
}
export declare function parseOptifineFilename(name: string): Omit<OptifineVersion, "downloadUrl"> | null;
export declare function optifineVersionId(mcVersion: string, filename: string): string;
export declare class OptifineHandler {
    private downloader;
    private metaClient;
    private gameDir;
    constructor(downloader: Downloader, metaClient: MetaClient, gameDir: string);
    /**
     * Fetch the OptiFine downloads page once and return all unique
     * Minecraft versions that have at least one OptiFine build available
     * (e.g. "1.7.10", "1.12.2", "1.16.5", …).
     *
     * Ported from optifine-utils getVersions() — single HTTP request
     * instead of per-mc-version polling.
     */
    getSupportedVersions(): Promise<string[]>;
    /**
     * Fetch the OptiFine downloads page once and return ALL available
     * OptiFine builds across every Minecraft version.
     *
     * Ported from optifine-utils getVersions() — single HTTP request.
     */
    getAllVersions(): Promise<OptifineVersion[]>;
    getVersions(mcVersion: string): Promise<OptifineVersion[]>;
    getRecommendedVersion(mcVersion: string): Promise<OptifineVersion | undefined>;
    getLatestVersion(mcVersion: string): Promise<OptifineVersion | undefined>;
    private withPhase;
    install(mcVersion: string, loaderVersion: string, onProgress?: DownloadProgressCallback): Promise<LoaderInstallResult>;
    private ensureInstallerDownloaded;
    private ensureVanillaClientJar;
    private resolveInstallerInfo;
    private findVersion;
    private extractBundledLaunchwrapper;
    private detectLaunchwrapperVersion;
    private buildVersionJson;
    private buildOptifineLibrary;
    private buildLaunchwrapperLibrary;
    private patchClientJar;
}
//# sourceMappingURL=optifine-handler.d.ts.map