import { LoaderInstallResult, DownloadProgressCallback } from "../types/index.js";
import { Downloader } from "../core/downloader.js";
import { MetaClient } from "../core/meta-client.js";
export declare class ForgeHandler {
    private downloader;
    private metaClient;
    private gameDir;
    constructor(downloader: Downloader, metaClient: MetaClient, gameDir: string);
    private normalizeForgeVersion;
    private findJava11;
    private fetchVersionIndex;
    private fetchMetadata;
    private fetchPromotions;
    getSupportedMinecraftVersions(): Promise<string[]>;
    getVersions(mcVersion: string): Promise<string[]>;
    getRecommendedVersion(mcVersion: string): Promise<string | undefined>;
    getLatestVersion(mcVersion: string): Promise<string | undefined>;
    private withPhase;
    private getPreferredRepositoryBase;
    private normalizeExternalLibraryUrl;
    private normalizeLibraryBaseUrl;
    private normalizeProfileLibrary;
    private normalizeInstallerProfile;
    private normalizeVersionLibrary;
    private isValidForgeInstallerArchive;
    private ensureInstallerArchive;
    install(mcVersion: string, forgeVersion: string, onProgress?: DownloadProgressCallback): Promise<LoaderInstallResult>;
    private downloadProfileLibraries;
    private mergeBaseMetadata;
    private buildLocalLibrary;
    private buildSupplementalLibraries;
    private normalizeInstallerVersionJson;
    private extractBundledArtifact;
    private ensureForgeArtifacts;
    /**
     * Create the patched client JAR.
     * Strategy:
     * 1. Validate the generated client jar against the installer-declared SHA.
     * 2. Run the official Forge client processor chain when available.
     * 3. Fall back to legacy binary patching for older installer layouts.
     */
    private createPatchedClientJar;
    private getPatchedClientJarPath;
    private getProfileDataValue;
    private mavenDescriptorToPath;
    private isGeneratedClientJarValid;
    private assertGeneratedClientJarValid;
    private runForgeInstallerClientProcessors;
    /**
     * Run binary patching to create the patched client JAR.
     * This extracts client.lzma from the installer, downloads the vanilla MC jar,
     * and runs binarypatcher to apply the patch.
     */
    private runBinaryPatching;
    /**
     * Download binarypatcher dependencies (srgutils, jopt-simple, lzma-java, javaxdelta, trove).
     */
    private downloadBinaryPatcherDeps;
    private buildVersionJsonFromProfile;
}
//# sourceMappingURL=forge-handler.d.ts.map