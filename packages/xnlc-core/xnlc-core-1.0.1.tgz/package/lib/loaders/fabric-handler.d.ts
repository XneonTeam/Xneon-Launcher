import { FabricGameVersion, FabricLoaderVersion, LoaderInstallResult, DownloadProgressCallback } from "../types/index.js";
import { Downloader } from "../core/downloader.js";
export declare class FabricHandler {
    private downloader;
    private gameDir;
    constructor(downloader: Downloader, gameDir: string);
    getGameVersions(): Promise<FabricGameVersion[]>;
    getLoaderVersions(): Promise<FabricLoaderVersion[]>;
    getLoaderVersionsForGame(mcVersion: string): Promise<FabricLoaderVersion[]>;
    getLatestLoaderVersion(mcVersion: string): Promise<string | undefined>;
    private withPhase;
    install(mcVersion: string, loaderVersion: string, onProgress?: DownloadProgressCallback): Promise<LoaderInstallResult>;
    private libraryNameToPath;
}
//# sourceMappingURL=fabric-handler.d.ts.map