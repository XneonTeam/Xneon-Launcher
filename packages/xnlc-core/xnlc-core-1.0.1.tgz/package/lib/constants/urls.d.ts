export declare const URLS: {
    readonly official: {
        readonly mojang: {
            readonly meta: "https://launchermeta.mojang.com";
            readonly launcher: "https://launcher.mojang.com";
            readonly versionManifest: "https://launchermeta.mojang.com/mc/game/version_manifest.json";
            readonly versionManifestV2: "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";
            readonly libraries: "https://libraries.minecraft.net";
            readonly assets: "https://resources.download.minecraft.net";
        };
        readonly forge: {
            readonly files: "https://files.minecraftforge.net";
            readonly maven: "https://maven.minecraftforge.net";
        };
        readonly fabric: {
            readonly meta: "https://meta.fabricmc.net";
            readonly metaV2: "https://meta.fabricmc.net/v2";
            readonly maven: "https://maven.fabricmc.net";
        };
        readonly neoforge: {
            readonly host: "https://maven.neoforged.net";
            readonly maven: "https://maven.neoforged.net/releases";
            readonly mirror: "https://mirrors.neoforged.net";
        };
        readonly quilt: {
            readonly meta: "https://meta.quiltmc.org";
            readonly metaV3: "https://meta.quiltmc.org/v3";
            readonly mavenRelease: "https://maven.quiltmc.org/repository/release";
            readonly mavenHost: "https://maven.quiltmc.org";
        };
        readonly optifine: {
            readonly root: "https://optifine.net";
            readonly downloads: "https://optifine.net/downloads";
        };
        readonly authlibInjector: {
            readonly root: "https://authlib-injector.yushi.moe";
        };
        readonly azul: {
            readonly metadataApi: "https://api.azul.com/metadata/v1/zulu/packages";
        };
        readonly mavenCentral: "https://repo1.maven.org/maven2";
        readonly mavenCentralApache: "https://repo.maven.apache.org/maven2";
        readonly sourceForgeLzma: "https://sourceforge.net/projects/kcauldron/files/lzma/lzma/0.0.1/lzma-0.0.1.jar/download";
        readonly mcArchiveForgeHelp: "https://mcarchive.net/mods/minecraftforge?gvsn=1.7.10";
    };
};
//# sourceMappingURL=urls.d.ts.map