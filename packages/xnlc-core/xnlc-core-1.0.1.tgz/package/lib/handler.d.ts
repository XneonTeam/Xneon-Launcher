import { Xnlc } from './xnlc.js';
import type { LoaderType, AuthSession } from './types/index.js';
export interface HandlerOptions {
    gameDir?: string;
    javaPath?: string;
    memoryMax?: string;
    memoryMin?: string;
    width?: number;
    height?: number;
}
export interface DefaultHandlerOptions extends HandlerOptions {
    platform?: NodeJS.Platform;
    env?: NodeJS.ProcessEnv;
    launcherDirName?: string;
}
export interface LaunchOptions {
    mcVersion: string;
    loaderType?: LoaderType;
    loaderVersion?: string;
    javaPath?: string;
    memoryMin?: string;
    memoryMax?: string;
    width?: number;
    height?: number;
}
export interface VersionInfo {
    id: string;
    type: 'release' | 'snapshot' | 'old_alpha' | 'old_beta';
    url?: string;
    releaseTime?: string;
}
export interface ModLoaderInfo {
    version: string;
    stable?: boolean;
}
export declare function createDefaultHandler(options?: DefaultHandlerOptions): XnlcHandler;
export declare class XnlcHandler {
    private xnlc;
    private auth;
    constructor(options?: HandlerOptions);
    getVersions(): Promise<VersionInfo[]>;
    getLatestRelease(): Promise<string>;
    getLatestSnapshot(): Promise<string>;
    getForgeVersions(mcVersion: string): Promise<string[]>;
    getForgeRecommended(mcVersion: string): Promise<string | undefined>;
    getNeoForgeVersions(mcVersion: string): Promise<string[]>;
    getNeoForgeRecommended(mcVersion: string): Promise<string | undefined>;
    getFabricGameVersions(): Promise<{
        version: string;
        stable: boolean;
    }[]>;
    getFabricSupportedVersions(): Promise<string[]>;
    getFabricVersions(mcVersion: string): Promise<ModLoaderInfo[]>;
    getQuiltGameVersions(): Promise<{
        version: string;
        stable: boolean;
    }[]>;
    getQuiltSupportedVersions(): Promise<string[]>;
    getQuiltVersions(mcVersion: string): Promise<ModLoaderInfo[]>;
    getNeoForgeSupportedVersions(): Promise<string[]>;
    getForgeSupportedVersions(): Promise<string[]>;
    getOptifineSupportedVersions(): Promise<string[]>;
    getOptifineVersions(mcVersion: string): Promise<{
        filename: string;
        isPreview: boolean;
    }[]>;
    getOptifineRecommended(mcVersion: string): Promise<{
        filename: string;
    } | undefined>;
    getCustomVersions(): Promise<string[]>;
    setOfflineAuth(username: string): void;
    getAuth(): AuthSession | null;
    launch(options: LaunchOptions, onProgress?: (info: {
        percent: number;
        file: string;
    }) => void): Promise<void>;
    launchVanilla(mcVersion: string, username: string): Promise<void>;
    launchForge(mcVersion: string, forgeVersion: string, username: string): Promise<void>;
    launchFabric(mcVersion: string, fabricVersion: string, username: string): Promise<void>;
    launchNeoForge(mcVersion: string, neoforgeVersion: string, username: string): Promise<void>;
    launchQuilt(mcVersion: string, quiltVersion: string, username: string): Promise<void>;
    interactiveLaunch(username: string): Promise<void>;
    getXnlc(): Xnlc;
}
export default XnlcHandler;
//# sourceMappingURL=handler.d.ts.map